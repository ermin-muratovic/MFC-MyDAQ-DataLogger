# MFC-MyDAQ-DataLogger

Informatik2 Project @ FHKärnten/EngIT/SE/B2-SS2017:

MFC-Application "MyDAQ-DataLogger" as in NIElvismx DataLogger

## Getting Started

Clone this project and execute in Visual Studio or download and start DataLogger.exe

### Prerequisites

* Visual Studio
* C++ Coding Tools

## Authors

* [**Ermin Muratovic**](https://github.com/ermin-muratovic) - *owner*
* [**Andreas Mörtlitsch**](https://github.com/Moertan)

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## Acknowledgments

Thanks's to everybody supporting this project.
