
// stdafx.cpp : Quelldatei, die nur die Standard-Includes einbindet.
// MFC-MyDAQ-DataLogger.pch ist der vorkompilierte Header.
// stdafx.obj enth�lt die vorkompilierten Typinformationen.

#include "stdafx.h"


