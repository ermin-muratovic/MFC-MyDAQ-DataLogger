//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by MFC-MyDAQ-DataLogger.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_MFCMYDAQDATALOGGER_DIALOG   102
#define IDR_MAINFRAME                   128
#define IDB_START                       129
#define IDB_STOP                        130
#define IDC_BUTTON1                     1000
#define IDC_BUTTONSTART                 1000
#define IDC_MYDAQ_NAME_LABEL            1002
#define IDC_DEVICECOMBO                 1003
#define IDC_BUTTONSTOP                  1004
#define IDC_MYDAQ_NAME_LABEL2           1005
#define IDC_MYDAQ_NAME_LABEL3           1006
#define IDC_MYDAQ_NAME_LABEL4           1007
#define IDC_CHANNELSLIST                1008
#define IDC_MYDAQ_NAME_LABEL5           1009
#define IDC_DATALOGGERLABEL             1016
#define IDC_SAMPLINGRATE                1017
#define IDC_SPIN1                       1018
#define IDC_MINV                        1019
#define IDC_SPIN2                       1020
#define IDC_MAXV                        1021
#define IDC_SPIN3                       1022
#define IDC_CUSTOM1                     1024
#define IDC_CUSTOM3                     1027
#define IDC_GRAPH                       1027
#define IDC_CHECK1                      1028
#define IDC_CHECKLOGTOFILE              1028
#define IDC_EDIT1                       1029
#define IDC_BUTTONSELECTFILE            1030

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1031
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
